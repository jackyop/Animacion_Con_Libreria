package carlor.animacionconlibreria;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.daasuu.library.DisplayObject;
import com.daasuu.library.FPSTextureView;
import com.daasuu.library.callback.AnimCallBack;
import com.daasuu.library.drawer.BitmapDrawer;
import com.daasuu.library.drawer.SpriteSheetDrawer;
import com.daasuu.library.easing.Ease;

public class MainActivity extends AppCompatActivity {
    private FPSTextureView mFPSTextureView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFPSTextureView = (FPSTextureView) findViewById(R.id.animation_texture_view);
        Bitmap draco = BitmapFactory.decodeResource(getResources(), R.drawable.img2);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        Bitmap agumon = BitmapFactory.decodeResource(getResources(), R.drawable.img1);

        DisplayObject bitmapDisplay = new DisplayObject();
        bitmapDisplay
                .with(new BitmapDrawer(bitmap))
                .tween()
                .tweenLoop(true)
                .toX(1600, 450, Ease.BACK_IN_OUT)
                .waitTime(1000)
                .end();

        SpriteSheetDrawer dracoo = new SpriteSheetDrawer(
                draco,
                200,
                200,
                5)
                .spriteLoop(true);

        DisplayObject displayObject = new DisplayObject();
        displayObject
                .with(dracoo)
                .tween()
                .tweenLoop(true)
                .transform(0, 125)
                .toX(3000, 450)
                .end();

        SpriteSheetDrawer agumonn = new SpriteSheetDrawer(
                agumon,
                50,
                60,
                7).spriteLoop(true);

        DisplayObject displayObject2 = new DisplayObject();
        displayObject2
                .with(agumonn)
                .parabolic()
                .accelerationX(20)
                .initialVelocityY(10)
                .transform(0, 300)
                .end();
        mFPSTextureView
                .addChild(bitmapDisplay)
                .addChild(displayObject)
                .addChild(displayObject2)
                .tickStart();
    }
}
